<?php
/**
 * Email Configuration
 * This file stores the email server connection parameters
 */

return [
    'host' => 'smtp.hostinger.com',
    'username' => 'cmsa@cmsa.digital',
    'password' => 'Tlp33241234@',
    'port' => 587,
    'encryption' => 'tls', // 'tls' or 'ssl'
    'from_email' => 'cmsa@cmsa.digital',
    'from_name' => 'CMSA Digital'
]; 