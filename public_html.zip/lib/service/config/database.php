<?php
/**
 * Database Configuration
 * This file stores the database connection parameters
 */

return [
    'host' => 'localhost',
    'username' => 'u237859360_bcfeszjing',
    'password' => 'Tlp33241234@',
    'database' => 'u237859360_cmsa'
]; 