<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

// Include the database connection helper
require_once $_SERVER['DOCUMENT_ROOT'] . '/lib/service/config/db_connect.php';

// Get database connection
$conn = getDbConnection();

$paper_id = isset($_POST['paper_id']) ? $_POST['paper_id'] : '';
$paper_doi = isset($_POST['paper_doi']) ? $_POST['paper_doi'] : '';
$paper_pageno = isset($_POST['paper_pageno']) ? $_POST['paper_pageno'] : '';

if (empty($paper_id)) {
    die(json_encode([
        'success' => false,
        'message' => 'Paper ID is required'
    ]));
}

try {
    // Start transaction
    $conn->begin_transaction();

    // Get paper_ready from the database
    $query = "SELECT paper_ready FROM tbl_papers WHERE paper_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $paper_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $paper_ready = $row['paper_ready'];
    } else {
        throw new Exception("Paper not found");
    }
    
    // Check if paper_ready exists
    if (empty($paper_ready)) {
        throw new Exception("Paper ready filename not available");
    }

    // Update paper details (only doi and pageno)
    $update_query = "UPDATE tbl_papers 
                    SET paper_doi = ?, paper_pageno = ?
                    WHERE paper_id = ?";
                    
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("sss", $paper_doi, $paper_pageno, $paper_id);
    $stmt->execute();

    // Handle file upload if present
    if (isset($_FILES['paper_file']) && $_FILES['paper_file']['error'] == 0) {
        $file = $_FILES['paper_file'];
        
        // Use paper_ready as filename with .pdf extension
        $file_name = $paper_ready . '.pdf';
        
        // Set the proper upload directory
        $upload_dir = $_SERVER['DOCUMENT_ROOT'] . '/assets/papers/camera_ready/';
        
        // Make sure directory exists
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $upload_path = $upload_dir . $file_name;

        if (move_uploaded_file($file['tmp_name'], $upload_path)) {
            // File uploaded successfully - no need to update database
        } else {
            throw new Exception("Failed to upload file. Error code: " . $file['error']);
        }
    }

    // Commit transaction
    $conn->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Publishing details updated successfully'
    ]);

} catch (Exception $e) {
    // Rollback on error
    $conn->rollback();
    echo json_encode([
        'success' => false,
        'message' => 'Error updating publishing details: ' . $e->getMessage()
    ]);
}

if (isset($stmt)) {
    $stmt->close();
}
$conn->close();
?>
